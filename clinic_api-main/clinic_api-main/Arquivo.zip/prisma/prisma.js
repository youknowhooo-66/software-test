import { prismaClient } from "@prisma/client";
export const prismaClient = new PrismaClient();
