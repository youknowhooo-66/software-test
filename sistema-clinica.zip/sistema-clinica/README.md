# Para rodar o projeto

1 - npm install na raiz para instalar as dependencias

2 - rodar npm server para "ligar" o json server

2 - npm run dev para rodar o front


# Como funciona?

1) Na tela inicial, crie uma conta. Os dados serão incluidos na rota /users

2) Faça Login com a conta inserida

3) Será direcionado para o dashboard para criação de prontuário, exame e consulta.

